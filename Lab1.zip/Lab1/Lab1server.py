import socket             
s = socket.socket()         
print ("Socket successfully created")
port = 12345                
s.bind(('', port))         
print ("socket binded to %s" %(port)) 
s.listen(5)     
print ("socket is listening")            
while True: 
  c, addr = s.accept()     
  print ('Connection from', addr )
  
  data = c.recv(1024).decode()
  if data.startswith("HELLO|"):
    username = data[6:]
    c.send(("HIIII thanks for saying HELLO to me").encode())
    print("connection made to" + username)
  while True:
    try:
        string = c.recv(1042).decode()
        if string.startswith("MSG|"):
            
            if string[4:] == "":
               c.send("AY why didnt you say HELLO to me...rude much".encode())
               print("message was empty")
            
            elif string[4:] == "goodbye to you":
               c.send(("thanks" + username + "switching off").encode())
               c.close
               exit()
            else:
               print(string)
               c.send(("thanks"+ username + "Got your message".encode))
            
        elif string == ("EXIT|"):
           c.send(b"shoo go away")
           c.close()
           print ("Disconected and waiting for a new connection")
           break
        else:
            print("incorrect format of " + username)
            c.send(b'try again please')
            c.close()        
        
    except Exception as error:
        print(error)
        print("client connection broken" )
    if string[4:] == "goodday to you":
        c.close()
        exit()
    c.close()    
    break 
 
