import socket             
s = socket.socket()         
port = 12345                

s.connect(('127.0.0.1', port)) 
f = input('enter a message: ')

print('type exit to ruin our connection')

s.send (("HELLO|" + f).encode())
print (s.recv(1024).decode())
while True:
    try: 
        input_s = ("MSG|" + input()).encode()
        if "exit" in input_s.decode():
            s.send(b"EXIT|")
            print (s.recv(1024).decode())
            s.close()
            break
        s.send(input_s)
        print (s.recv(1024).decode())
    except:
        print("you broke our connection")
        s.close()
        break